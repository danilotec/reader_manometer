# ManometerDetection > 2023-11-08 6:34pm
https://universe.roboflow.com/insa-iiy2q/manometerdetection

Provided by a Roboflow user
License: CC BY 4.0

